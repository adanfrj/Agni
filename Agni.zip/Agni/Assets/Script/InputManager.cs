using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class InputManager
{
    
    // Start is called before the first frame update
    public static float MainHorizontal()
    {
        float r = 0.0f;
        r += Input.GetAxis ("K_MainHorizontal");
        return Mathf.Clamp (r, -1.0f, 1.0f);
    }

    public static float MainVertical()
    {
        float r = 0.0f;
        r += Input.GetAxis ("K_MainVertical");
        return Mathf.Clamp (r, -1.0f, 1.0f);
    }

    public static Vector3 MainKeyboard()
    {
        return new  Vector3 (MainHorizontal(),0,MainVertical());
    }

   public static bool JumpButton()
   {
     return Input.GetButtonDown("Jump");
   }
}
