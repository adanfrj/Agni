using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    private Transform target; //the enemy's target
    private float dist;
    public float moveSpeed;
    public float howClose;


    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        dist = Vector3.Distance(target.position, transform.position);

        if (dist <= howClose)
        {
            GetComponent<Rigidbody>().AddForce(transform.forward * moveSpeed);
            transform.position = Vector3.MoveTowards(transform.position, target.position, moveSpeed * Time.deltaTime);
        }

        if (dist <= 1.5f)
        {
            //do damage
        }
    }
}
